# SNS_Programming_Assignment
1. This Repo contains all the code and final report pertaining to the signals and systems programming assignment
2. In this we have to calculate the discrete time fourier transform of the given signal and plot it against it's corresponding frequency. 
3. We are considering 3 different sampling frequencies of 500, 2000 and 16000Hz. We have decided to make this assignment challenging for ourselves by using C++ instead of python/matlab where plotting graphs is much easier.

# Group Members
1. Jason Daniel (Repo Owner)
2. Rifa Khan
3. Ruchit Kochar
4. Karina Choudhary
